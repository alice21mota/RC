#ifndef AUXFUNCS_H
#define AUXFUNCS_H


#include "../clientSide/globalsClient/globals.h"
#include "../common/validations.h"

using namespace std;

size_t getFileSize(string asset_fname);

string fileSizeString(string asset_fname);


#endif // AUXFUNCS_H 